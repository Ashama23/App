import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Plus, Phone, Edit2, Trash2, UserCheck } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ContactModal } from "@/components/contact-modal";
import { BottomNavigation } from "@/components/bottom-navigation";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";

export default function Contacts() {
  const [isContactModalOpen, setIsContactModalOpen] = useState(false);
  const [selectedContact, setSelectedContact] = useState<any>(null);
  const { toast } = useToast();

  const { data: contacts, isLoading } = useQuery({
    queryKey: ["/api/emergency-contacts"],
  });

  const handleEditContact = (contact: any) => {
    setSelectedContact(contact);
    setIsContactModalOpen(true);
  };

  const handleDeleteContact = async (contactId: number) => {
    try {
      await apiRequest("DELETE", `/api/emergency-contacts/${contactId}`);
      queryClient.invalidateQueries({ queryKey: ["/api/emergency-contacts"] });
      queryClient.invalidateQueries({ queryKey: ["/api/emergency-contacts/primary"] });
      toast({
        title: "Contact Deleted",
        description: "Emergency contact has been removed.",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to delete contact. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleCallContact = (contact: any) => {
    window.open(`tel:${contact.countryCode || "+1"}${contact.phoneNumber}`, '_self');
  };

  const handleCloseModal = () => {
    setSelectedContact(null);
    setIsContactModalOpen(false);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-light-bg flex items-center justify-center">
        <div className="text-center">
          <div className="w-8 h-8 border-4 border-blue-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Loading contacts...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-light-bg">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200 sticky top-0 z-40">
        <div className="max-w-md mx-auto px-5 py-4">
          <div className="flex items-center justify-between">
            <h1 className="text-xl font-bold text-dark-text">Emergency Contacts</h1>
            <Button
              onClick={() => setIsContactModalOpen(true)}
              className="bg-info-blue hover:bg-blue-600 text-white"
              size="sm"
            >
              <Plus className="mr-2" size={16} />
              Add Contact
            </Button>
          </div>
        </div>
      </header>

      <div className="max-w-md mx-auto bg-white min-h-screen">
        <main className="p-5">
          {contacts && contacts.length > 0 ? (
            <div className="space-y-4">
              {contacts.map((contact: any) => (
                <Card key={contact.id} className="bg-white border border-gray-200">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center space-x-3">
                        <div className="w-12 h-12 bg-info-blue rounded-full flex items-center justify-center">
                          <Phone className="text-white" size={20} />
                        </div>
                        <div>
                          <div className="flex items-center space-x-2">
                            <h3 className="font-semibold text-dark-text">{contact.name}</h3>
                            {contact.isPrimary && (
                              <Badge className="bg-emergency-red text-white text-xs">
                                Primary
                              </Badge>
                            )}
                          </div>
                          <p className="text-sm text-gray-600">{contact.relationship}</p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleEditContact(contact)}
                          className="text-gray-500 hover:text-info-blue"
                        >
                          <Edit2 size={16} />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleDeleteContact(contact.id)}
                          className="text-gray-500 hover:text-red-500"
                        >
                          <Trash2 size={16} />
                        </Button>
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium text-dark-text">Phone Number</span>
                        <span className="text-sm text-gray-600">
                          {contact.countryCode || "+1"}{contact.phoneNumber}
                        </span>
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium text-dark-text">Status</span>
                        <div className="flex items-center space-x-2">
                          <div className={`w-2 h-2 rounded-full ${
                            contact.isVerified ? "bg-safe-green" : "bg-warning-amber"
                          }`}></div>
                          <span className="text-sm text-gray-600">
                            {contact.isVerified ? "Verified" : "Unverified"}
                          </span>
                        </div>
                      </div>
                    </div>

                    <div className="mt-4 flex space-x-2">
                      <Button
                        onClick={() => handleCallContact(contact)}
                        className="flex-1 bg-safe-green hover:bg-green-600 text-white"
                        size="sm"
                      >
                        <Phone className="mr-2" size={16} />
                        Call
                      </Button>
                      {contact.isPrimary && (
                        <Button
                          variant="outline"
                          className="flex-1 border-info-blue text-info-blue hover:bg-info-blue hover:text-white"
                          size="sm"
                        >
                          <UserCheck className="mr-2" size={16} />
                          Primary
                        </Button>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <div className="text-center py-16">
              <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Phone className="text-gray-400" size={24} />
              </div>
              <h3 className="text-lg font-semibold text-dark-text mb-2">No Emergency Contacts</h3>
              <p className="text-gray-600 mb-6">Add your first emergency contact to get started</p>
              <Button
                onClick={() => setIsContactModalOpen(true)}
                className="bg-info-blue hover:bg-blue-600 text-white"
              >
                <Plus className="mr-2" size={16} />
                Add Emergency Contact
              </Button>
            </div>
          )}
        </main>
        <BottomNavigation />
      </div>

      <ContactModal
        isOpen={isContactModalOpen}
        onClose={handleCloseModal}
        contact={selectedContact}
      />
    </div>
  );
}