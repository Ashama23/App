import { useState } from "react";
import { Settings, Shield, MapPin, Bell, Phone, HelpCircle, Info, ChevronRight, Toggle, Download, Code, Terminal } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { BottomNavigation } from "@/components/bottom-navigation";

export default function SettingsPage() {
  const [shakeDetection, setShakeDetection] = useState(true);
  const [locationTracking, setLocationTracking] = useState(true);
  const [notifications, setNotifications] = useState(true);
  const [autoDial, setAutoDial] = useState(true);
  const [autoSMS, setAutoSMS] = useState(true);

  const handleDownloadCode = () => {
    // Create a simple text file with download instructions
    const instructions = `# SafeGuard Women's Safety App

## Download Instructions

To download and run this application:

1. Clone or download the repository
2. Install dependencies: npm install
3. Run the application: npm run dev

## Requirements

- Node.js (version 18 or higher)
- npm package manager

## Features

- Emergency response system with shake detection
- GPS location sharing
- Automated SMS and call alerts
- Emergency contact management
- Activity logging and history
- International phone number support

## Tech Stack

- Frontend: React 18 + TypeScript + Tailwind CSS
- Backend: Node.js + Express
- Database: PostgreSQL (with in-memory storage for development)
- Build Tool: Vite

## Run Commands

Development: npm run dev
Build: npm run build
Start: npm start

For more details, check the README.md file in the project root.
`;

    const blob = new Blob([instructions], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'SafeGuard-App-Instructions.txt';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleDownloadProjectZip = async () => {
    try {
      // Create a link to trigger the download
      const link = document.createElement('a');
      link.href = '/api/download-project';
      link.download = 'SafeGuard-WomensSafety-App.zip';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch (error) {
      console.error('Error downloading project:', error);
      // Fallback to instructions if download fails
      const sourceGuide = `# SafeGuard Women's Safety App - Source Code Download

## Quick Setup Guide

### Method 1: Clone Repository
\`\`\`bash
git clone [repository-url]
cd safeguard-app
npm install
npm run dev
\`\`\`

### Method 2: Download ZIP
1. Download ZIP from repository page
2. Extract to desired folder
3. Open terminal in project folder
4. Run: npm install
5. Run: npm run dev

## Project Structure

safeguard-app/
├── client/                 # React frontend
│   ├── src/
│   │   ├── components/     # UI components
│   │   ├── pages/          # App pages
│   │   ├── hooks/          # Custom hooks
│   │   └── lib/            # Utilities
├── server/                 # Express backend
│   ├── index.ts           # Server entry
│   ├── routes.ts          # API routes
│   └── storage.ts         # Data layer
├── shared/                 # Shared schemas
└── package.json           # Dependencies

## Key Technologies

- Frontend: React 18 + TypeScript + Tailwind CSS
- Backend: Node.js + Express + TypeScript
- Database: PostgreSQL (dev uses in-memory)
- Build: Vite + ESBuild

## Features Included

✓ Emergency SOS system with shake detection
✓ GPS location sharing with Google Maps
✓ Automated SMS and call alerts
✓ International phone number support (20+ countries)
✓ Emergency contact management
✓ Activity logging and history
✓ Mobile-first responsive design
✓ Real-time emergency status updates

## Essential Commands

npm install          # Install dependencies
npm run dev          # Start development server
npm run build        # Build for production
npm start           # Start production server
npm run db:generate # Generate database migrations
npm run db:push     # Push schema changes

## Requirements

- Node.js 18+
- npm package manager
- Modern web browser
- PostgreSQL (for production)

## Access After Setup

Development server: http://localhost:5000
The app includes:
- Dashboard with emergency button
- Contacts management
- Activity history
- Settings and configuration

## Support

- Check README.md for detailed setup
- Review code comments for implementation details
- All emergency features are fully functional
- Pakistan (+92) country code included

Happy coding! 🚨`;

      const blob = new Blob([sourceGuide], { type: 'text/plain' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'SafeGuard-Source-Code-Guide.txt';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    }
  };

  const settingsGroups = [
    {
      title: "Emergency Features",
      icon: <Shield className="text-red-500" size={20} />,
      items: [
        {
          id: "shake",
          label: "Shake Detection",
          description: "Activate emergency by shaking phone 3 times",
          value: shakeDetection,
          onChange: setShakeDetection
        },
        {
          id: "location",
          label: "Location Tracking",
          description: "Share precise location during emergencies",
          value: locationTracking,
          onChange: setLocationTracking
        },
        {
          id: "autosms",
          label: "Auto SMS",
          description: "Automatically send SMS to emergency contact",
          value: autoSMS,
          onChange: setAutoSMS
        },
        {
          id: "autodial",
          label: "Auto Call",
          description: "Automatically call emergency contact",
          value: autoDial,
          onChange: setAutoDial
        }
      ]
    },
    {
      title: "Notifications",
      icon: <Bell className="text-blue-500" size={20} />,
      items: [
        {
          id: "notifications",
          label: "Push Notifications",
          description: "Receive alerts and status updates",
          value: notifications,
          onChange: setNotifications
        }
      ]
    },
    {
      title: "Privacy & Security",
      icon: <Shield className="text-green-500" size={20} />,
      items: [
        {
          id: "privacy",
          label: "Privacy Policy",
          description: "View privacy and data usage policy",
          action: "link"
        },
        {
          id: "security",
          label: "Security Settings",
          description: "Manage app security and permissions",
          action: "link"
        }
      ]
    },
    {
      title: "Developer",
      icon: <Code className="text-purple-500" size={20} />,
      items: [
        {
          id: "download",
          label: "Download Instructions",
          description: "Get setup instructions and run commands",
          action: "download"
        },
        {
          id: "source",
          label: "Source Code",
          description: "Download the complete project source",
          action: "source"
        }
      ]
    },
    {
      title: "Support",
      icon: <HelpCircle className="text-amber-500" size={20} />,
      items: [
        {
          id: "help",
          label: "Help & FAQ",
          description: "Get help and view frequently asked questions",
          action: "link"
        },
        {
          id: "contact",
          label: "Contact Support",
          description: "Get in touch with our support team",
          action: "link"
        },
        {
          id: "feedback",
          label: "Send Feedback",
          description: "Help us improve the app",
          action: "link"
        }
      ]
    }
  ];

  return (
    <div className="min-h-screen bg-light-bg">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200 sticky top-0 z-40">
        <div className="max-w-md mx-auto px-5 py-4">
          <h1 className="text-xl font-bold text-dark-text">Settings</h1>
        </div>
      </header>

      <div className="max-w-md mx-auto bg-white min-h-screen">
        <main className="p-5 space-y-6">
          {/* Download Source Code Button */}
          <Card className="bg-gradient-to-r from-blue-500 to-blue-600 text-white">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="w-12 h-12 bg-white bg-opacity-20 rounded-full flex items-center justify-center">
                    <Download className="text-white" size={24} />
                  </div>
                  <div>
                    <h2 className="text-lg font-semibold">Download Source Code</h2>
                    <p className="text-sm opacity-90">Get the complete SafeGuard app source</p>
                  </div>
                </div>
                <Button
                  onClick={handleDownloadProjectZip}
                  className="bg-white bg-opacity-20 hover:bg-opacity-30 text-white border-white border"
                  size="sm"
                >
                  <Code className="mr-2" size={16} />
                  Download
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* App Info */}
          <Card className="bg-gradient-to-r from-red-500 to-red-600 text-white">
            <CardContent className="p-4">
              <div className="flex items-center space-x-3">
                <div className="w-12 h-12 bg-white bg-opacity-20 rounded-full flex items-center justify-center">
                  <Shield className="text-white" size={24} />
                </div>
                <div>
                  <h2 className="text-lg font-semibold">SafeGuard</h2>
                  <p className="text-sm opacity-90">Emergency Protection App</p>
                </div>
              </div>
              <div className="mt-4 flex items-center justify-between">
                <div>
                  <p className="text-sm opacity-90">Version 1.0.0</p>
                  <p className="text-xs opacity-75">Updated today</p>
                </div>
                <Badge className="bg-white bg-opacity-20 text-white">
                  Active
                </Badge>
              </div>
            </CardContent>
          </Card>

          {/* Settings Groups */}
          {settingsGroups.map((group, groupIndex) => (
            <div key={groupIndex} className="space-y-3">
              <div className="flex items-center space-x-2">
                {group.icon}
                <h3 className="text-lg font-semibold text-dark-text">{group.title}</h3>
              </div>
              
              <Card className="bg-white border border-gray-200">
                <CardContent className="p-0">
                  {group.items.map((item, itemIndex) => (
                    <div
                      key={item.id}
                      className={`p-4 ${
                        itemIndex < group.items.length - 1 ? "border-b border-gray-100" : ""
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex-1">
                          <div className="flex items-center space-x-2">
                            <span className="font-medium text-dark-text">{item.label}</span>
                          </div>
                          <p className="text-sm text-gray-600 mt-1">{item.description}</p>
                        </div>
                        
                        <div className="ml-4">
                          {item.onChange ? (
                            <Switch
                              checked={item.value}
                              onCheckedChange={item.onChange}
                              className="data-[state=checked]:bg-info-blue"
                            />
                          ) : item.action === "download" ? (
                            <Button 
                              variant="ghost" 
                              size="sm" 
                              className="text-info-blue"
                              onClick={handleDownloadCode}
                            >
                              <Download size={16} />
                            </Button>
                          ) : item.action === "source" ? (
                            <Button 
                              variant="ghost" 
                              size="sm" 
                              className="text-info-blue"
                              onClick={handleDownloadProjectZip}
                            >
                              <Code size={16} />
                            </Button>
                          ) : (
                            <Button variant="ghost" size="sm" className="text-gray-400">
                              <ChevronRight size={16} />
                            </Button>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>
            </div>
          ))}

          {/* Emergency Status */}
          <Card className="bg-green-50 border border-green-200">
            <CardContent className="p-4">
              <div className="flex items-center space-x-3">
                <div className="w-3 h-3 bg-safe-green rounded-full"></div>
                <div>
                  <h3 className="font-semibold text-dark-text">System Status</h3>
                  <p className="text-sm text-gray-600">All emergency systems are operational</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Run Commands */}
          <Card className="bg-blue-50 border border-blue-200">
            <CardContent className="p-4">
              <div className="flex items-center space-x-3 mb-3">
                <Terminal className="text-blue-600" size={20} />
                <h3 className="font-semibold text-dark-text">Run Commands</h3>
              </div>
              <div className="space-y-3">
                <div className="bg-gray-800 rounded-lg p-3 font-mono text-sm">
                  <div className="text-green-400 mb-1"># Install dependencies</div>
                  <div className="text-white">npm install</div>
                </div>
                <div className="bg-gray-800 rounded-lg p-3 font-mono text-sm">
                  <div className="text-green-400 mb-1"># Run development server</div>
                  <div className="text-white">npm run dev</div>
                </div>
                <div className="bg-gray-800 rounded-lg p-3 font-mono text-sm">
                  <div className="text-green-400 mb-1"># Build for production</div>
                  <div className="text-white">npm run build</div>
                </div>
                <div className="bg-gray-800 rounded-lg p-3 font-mono text-sm">
                  <div className="text-green-400 mb-1"># Start production server</div>
                  <div className="text-white">npm start</div>
                </div>
              </div>
              <p className="text-xs text-gray-600 mt-3">
                Requires Node.js 18+ and npm package manager
              </p>
            </CardContent>
          </Card>

          {/* About */}
          <Card className="bg-gray-50 border border-gray-200">
            <CardContent className="p-4">
              <div className="flex items-center space-x-3 mb-3">
                <Info className="text-gray-500" size={20} />
                <h3 className="font-semibold text-dark-text">About SafeGuard</h3>
              </div>
              <p className="text-sm text-gray-600 mb-3">
                SafeGuard is a women's safety application designed to provide emergency assistance 
                through automated SMS and call features with precise location sharing.
              </p>
              <div className="space-y-2 text-xs text-gray-500">
                <p>• Shake detection for hands-free emergency activation</p>
                <p>• Automatic SMS with Google Maps location</p>
                <p>• Instant emergency calling to primary contact</p>
                <p>• International phone number support</p>
                <p>• Comprehensive activity logging</p>
              </div>
            </CardContent>
          </Card>

          {/* Legal */}
          <div className="text-center space-y-2 pb-8">
            <p className="text-xs text-gray-500">
              By using SafeGuard, you agree to our Terms of Service and Privacy Policy
            </p>
            <div className="flex justify-center space-x-4">
              <Button variant="link" size="sm" className="text-xs text-gray-500">
                Terms of Service
              </Button>
              <Button variant="link" size="sm" className="text-xs text-gray-500">
                Privacy Policy
              </Button>
            </div>
          </div>
        </main>
        <BottomNavigation />
      </div>
    </div>
  );
}