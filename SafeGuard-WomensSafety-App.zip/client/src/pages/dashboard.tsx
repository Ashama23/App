import { useQuery } from "@tanstack/react-query";
import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Shield, Settings, Cog, Phone, MessageSquare, MapPin, Clock } from "lucide-react";
import { EmergencyButton } from "@/components/emergency-button";
import { EmergencyModal } from "@/components/emergency-modal";
import { ContactModal } from "@/components/contact-modal";
import { StatusCard } from "@/components/status-card";
import { ActivityLog } from "@/components/activity-log";
import { BottomNavigation } from "@/components/bottom-navigation";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { useShakeDetection } from "@/hooks/use-shake-detection";
import { useGeolocation } from "@/hooks/use-geolocation";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

export default function Dashboard() {
  const [isEmergencyModalOpen, setIsEmergencyModalOpen] = useState(false);
  const [isContactModalOpen, setIsContactModalOpen] = useState(false);
  const [currentTime, setCurrentTime] = useState(new Date());
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const { location, requestLocation } = useGeolocation();

  // Queries
  const { data: primaryContact } = useQuery({
    queryKey: ["/api/emergency-contacts/primary"],
  });

  const { data: emergencyLogs } = useQuery({
    queryKey: ["/api/emergency-logs"],
  });

  const { data: activeLog } = useQuery({
    queryKey: ["/api/emergency-logs/active"],
    refetchInterval: 5000,
  });

  // Update time every second
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  // Shake detection
  useShakeDetection((shakeCount) => {
    if (shakeCount >= 3) {
      handleEmergencyTrigger();
    }
  });

  const handleEmergencyTrigger = async () => {
    if (!primaryContact) {
      toast({
        title: "No Emergency Contact",
        description: "Please set up an emergency contact first.",
        variant: "destructive",
      });
      return;
    }

    try {
      const currentLocation = await requestLocation();
      if (!currentLocation) {
        toast({
          title: "Location Required",
          description: "Location access is required for emergency alerts.",
          variant: "destructive",
        });
        return;
      }

      setIsEmergencyModalOpen(true);
      
      await apiRequest("POST", "/api/emergency/trigger", {
        location: currentLocation,
        type: "emergency",
      });

      toast({
        title: "Emergency Alert Triggered",
        description: "Emergency contact has been notified.",
      });
    } catch (error) {
      toast({
        title: "Emergency Alert Failed",
        description: "Failed to trigger emergency alert. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleTestEmergency = async () => {
    if (!primaryContact) {
      toast({
        title: "No Emergency Contact",
        description: "Please set up an emergency contact first.",
        variant: "destructive",
      });
      return;
    }

    try {
      const currentLocation = await requestLocation();
      await apiRequest("POST", "/api/emergency/trigger", {
        location: currentLocation,
        type: "test",
      });

      toast({
        title: "Test Alert Sent",
        description: "Test emergency alert sent successfully.",
      });
    } catch (error) {
      toast({
        title: "Test Failed",
        description: "Failed to send test alert.",
        variant: "destructive",
      });
    }
  };

  const handleShareLocation = async () => {
    try {
      const currentLocation = await requestLocation();
      if (!currentLocation) {
        toast({
          title: "Location Required",
          description: "Location access is required to share location.",
          variant: "destructive",
        });
        return;
      }

      await apiRequest("POST", "/api/location/share", {
        location: currentLocation,
      });

      const googleMapsLink = `https://maps.google.com/?q=${currentLocation.latitude},${currentLocation.longitude}`;
      
      if (navigator.share) {
        await navigator.share({
          title: "My Current Location",
          text: "Here is my current location:",
          url: googleMapsLink,
        });
      } else {
        navigator.clipboard.writeText(googleMapsLink);
        toast({
          title: "Location Copied",
          description: "Location link copied to clipboard.",
        });
      }
    } catch (error) {
      toast({
        title: "Share Failed",
        description: "Failed to share location.",
        variant: "destructive",
      });
    }
  };

  const handleCallContact = () => {
    if (primaryContact) {
      window.open(`tel:${primaryContact.countryCode || "+1"}${primaryContact.phoneNumber}`, '_self');
    }
  };

  const handleMessageContact = () => {
    if (primaryContact) {
      const message = `🚨 Emergency alert from SafeGuard app. Current location: ${location ? `https://maps.google.com/?q=${location.latitude},${location.longitude}` : 'Location unavailable'}`;
      window.open(`sms:${primaryContact.countryCode || "+1"}${primaryContact.phoneNumber}?body=${encodeURIComponent(message)}`, '_self');
    }
  };

  return (
    <div className="min-h-screen bg-light-bg">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200 sticky top-0 z-40">
        <div className="max-w-md mx-auto px-5 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-emergency-red rounded-full flex items-center justify-center">
                <Shield className="text-white" size={20} />
              </div>
              <div>
                <h1 className="text-xl font-bold text-dark-text">SafeGuard</h1>
                <p className="text-xs text-gray-500">Emergency Protection</p>
              </div>
            </div>
            <div className="flex items-center space-x-3">
              <div className="flex items-center space-x-1">
                <div className="w-2 h-2 bg-safe-green rounded-full"></div>
                <span className="text-xs text-gray-600">Online</span>
              </div>
              <Button variant="ghost" size="sm">
                <Settings className="text-gray-500" size={18} />
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-md mx-auto bg-white min-h-screen">
        <main className="p-5 space-y-6">
          {/* Status Card */}
          <StatusCard 
            currentTime={currentTime}
            isShakeDetectionActive={true}
            activeLog={activeLog}
          />

          {/* Emergency SOS Button */}
          <div className="text-center">
            <EmergencyButton 
              onEmergencyTrigger={handleEmergencyTrigger}
              isActive={!!activeLog}
            />
            <p className="text-gray-600 text-sm mt-4 max-w-xs mx-auto">
              Press and hold for 3 seconds or shake your phone 3 times to activate emergency alert
            </p>
          </div>

          {/* Quick Actions */}
          <div className="grid grid-cols-2 gap-4">
            <Button 
              onClick={handleTestEmergency}
              className="bg-info-blue hover:bg-blue-600 text-white rounded-xl p-4 h-auto flex flex-col items-center space-y-2 touch-button"
            >
              <Cog size={20} />
              <span className="text-sm font-medium">Test Alert</span>
            </Button>
            <Button 
              onClick={handleShareLocation}
              className="bg-warning-amber hover:bg-yellow-600 text-white rounded-xl p-4 h-auto flex flex-col items-center space-y-2 touch-button"
            >
              <MapPin size={20} />
              <span className="text-sm font-medium">Share Location</span>
            </Button>
          </div>

          {/* Emergency Contact */}
          <Card className="bg-gray-50">
            <CardContent className="p-5">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-dark-text">Emergency Contact</h3>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setIsContactModalOpen(true)}
                  className="text-info-blue hover:text-blue-600"
                >
                  Edit
                </Button>
              </div>
              
              {primaryContact ? (
                <div className="space-y-3">
                  <div className="flex items-center space-x-3">
                    <div className="w-12 h-12 bg-info-blue rounded-full flex items-center justify-center">
                      <Phone className="text-white" size={20} />
                    </div>
                    <div className="flex-1">
                      <p className="font-medium text-dark-text">{primaryContact.name}</p>
                      <p className="text-sm text-gray-600">{primaryContact.relationship}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-medium text-dark-text">{primaryContact.countryCode || "+1"}{primaryContact.phoneNumber}</p>
                      <p className="text-xs text-gray-500">
                        {primaryContact.isVerified ? "Verified" : "Unverified"}
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex space-x-2">
                    <Button
                      onClick={handleCallContact}
                      className="flex-1 bg-safe-green hover:bg-green-600 text-white rounded-lg py-2 px-4 text-sm font-medium"
                    >
                      <Phone className="mr-2" size={16} />
                      Call
                    </Button>
                    <Button
                      onClick={handleMessageContact}
                      className="flex-1 bg-info-blue hover:bg-blue-600 text-white rounded-lg py-2 px-4 text-sm font-medium"
                    >
                      <MessageSquare className="mr-2" size={16} />
                      Message
                    </Button>
                  </div>
                </div>
              ) : (
                <div className="text-center py-8">
                  <p className="text-gray-600 mb-4">No emergency contact set</p>
                  <Button
                    onClick={() => setIsContactModalOpen(true)}
                    className="bg-info-blue hover:bg-blue-600 text-white"
                  >
                    Add Emergency Contact
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Activity Log */}
          <ActivityLog logs={emergencyLogs || []} />

          {/* Location Services */}
          <Card className="bg-white border border-gray-200">
            <CardContent className="p-5">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-dark-text">Location Services</h3>
                <div className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-safe-green rounded-full"></div>
                  <span className="text-xs text-gray-600">
                    {location ? "Active" : "Inactive"}
                  </span>
                </div>
              </div>
              
              <div className="space-y-3">
                <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div className="flex items-center space-x-3">
                    <MapPin className="text-info-blue" size={20} />
                    <div>
                      <p className="text-sm font-medium text-dark-text">GPS Accuracy</p>
                      <p className="text-xs text-gray-600">High precision enabled</p>
                    </div>
                  </div>
                  <span className="text-sm font-medium text-safe-green">
                    {location ? `±${Math.round(location.accuracy)}m` : "N/A"}
                  </span>
                </div>
                
                <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div className="flex items-center space-x-3">
                    <Clock className="text-info-blue" size={20} />
                    <div>
                      <p className="text-sm font-medium text-dark-text">Last Updated</p>
                      <p className="text-xs text-gray-600">Continuous tracking</p>
                    </div>
                  </div>
                  <span className="text-sm font-medium text-dark-text">
                    {location ? "Just now" : "Never"}
                  </span>
                </div>
              </div>
            </CardContent>
          </Card>
        </main>

        <BottomNavigation />
      </div>

      {/* Modals */}
      <EmergencyModal 
        isOpen={isEmergencyModalOpen}
        onClose={() => setIsEmergencyModalOpen(false)}
        emergencyContact={primaryContact}
      />
      
      <ContactModal 
        isOpen={isContactModalOpen}
        onClose={() => setIsContactModalOpen(false)}
        contact={primaryContact}
      />
    </div>
  );
}
