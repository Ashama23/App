import { useQuery } from "@tanstack/react-query";
import { CheckCircle, MapPin, UserCheck, Clock, Phone, MessageSquare, AlertTriangle } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { BottomNavigation } from "@/components/bottom-navigation";

export default function History() {
  const { data: logs, isLoading } = useQuery({
    queryKey: ["/api/emergency-logs"],
  });

  const getLogIcon = (type: string) => {
    switch (type) {
      case 'emergency':
        return <AlertTriangle className="text-red-500" size={20} />;
      case 'test':
        return <CheckCircle className="text-green-500" size={20} />;
      case 'location_share':
        return <MapPin className="text-blue-500" size={20} />;
      case 'sms_sent':
        return <MessageSquare className="text-blue-500" size={20} />;
      case 'call_initiated':
        return <Phone className="text-green-500" size={20} />;
      default:
        return <UserCheck className="text-amber-500" size={20} />;
    }
  };

  const getLogText = (log: any) => {
    switch (log.type) {
      case 'emergency':
        return 'Emergency Alert';
      case 'test':
        return 'Test Alert';
      case 'location_share':
        return 'Location Share';
      case 'sms_sent':
        return 'Emergency SMS';
      case 'call_initiated':
        return 'Emergency Call';
      default:
        return 'Unknown Activity';
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'completed':
        return <Badge className="bg-safe-green text-white">Completed</Badge>;
      case 'active':
        return <Badge className="bg-warning-amber text-white">Active</Badge>;
      case 'cancelled':
        return <Badge className="bg-gray-500 text-white">Cancelled</Badge>;
      case 'failed':
        return <Badge className="bg-red-500 text-white">Failed</Badge>;
      default:
        return <Badge className="bg-gray-400 text-white">Unknown</Badge>;
    }
  };

  const formatTime = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString() + ' ' + date.toLocaleTimeString([], { 
      hour: '2-digit', 
      minute: '2-digit' 
    });
  };

  const getLocationLink = (locationString: string) => {
    try {
      const location = JSON.parse(locationString);
      return `https://maps.google.com/?q=${location.latitude},${location.longitude}`;
    } catch {
      return null;
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-light-bg flex items-center justify-center">
        <div className="text-center">
          <div className="w-8 h-8 border-4 border-blue-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Loading history...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-light-bg">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200 sticky top-0 z-40">
        <div className="max-w-md mx-auto px-5 py-4">
          <h1 className="text-xl font-bold text-dark-text">Activity History</h1>
        </div>
      </header>

      <div className="max-w-md mx-auto bg-white min-h-screen">
        <main className="p-5">
          {logs && logs.length > 0 ? (
            <div className="space-y-4">
              {logs.map((log: any) => (
                <Card key={log.id} className="bg-white border border-gray-200">
                  <CardContent className="p-4">
                    <div className="flex items-start space-x-3">
                      <div className="w-12 h-12 bg-gray-50 rounded-full flex items-center justify-center border">
                        {getLogIcon(log.type)}
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center justify-between mb-2">
                          <h3 className="font-semibold text-dark-text">{getLogText(log)}</h3>
                          {getStatusBadge(log.status)}
                        </div>
                        
                        <p className="text-sm text-gray-600 mb-2">
                          {formatTime(log.createdAt)}
                        </p>
                        
                        {log.message && (
                          <p className="text-sm text-gray-700 mb-3 bg-gray-50 p-2 rounded">
                            {log.message}
                          </p>
                        )}
                        
                        {log.location && (
                          <div className="flex items-center space-x-2 mb-2">
                            <MapPin className="text-gray-400" size={16} />
                            <span className="text-sm text-gray-600">Location captured</span>
                            {getLocationLink(log.location) && (
                              <Button
                                variant="link"
                                size="sm"
                                className="text-info-blue p-0 h-auto"
                                onClick={() => window.open(getLocationLink(log.location), '_blank')}
                              >
                                View on Maps
                              </Button>
                            )}
                          </div>
                        )}
                        
                        {log.completedAt && (
                          <div className="flex items-center space-x-2">
                            <CheckCircle className="text-safe-green" size={16} />
                            <span className="text-sm text-gray-600">
                              Completed at {formatTime(log.completedAt)}
                            </span>
                          </div>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <div className="text-center py-16">
              <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Clock className="text-gray-400" size={24} />
              </div>
              <h3 className="text-lg font-semibold text-dark-text mb-2">No Activity History</h3>
              <p className="text-gray-600">Your emergency activities will appear here</p>
            </div>
          )}
        </main>
        <BottomNavigation />
      </div>
    </div>
  );
}