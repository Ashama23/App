import { CheckCircle, MapPin, UserCheck, Clock } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

interface ActivityLogProps {
  logs: any[];
}

export function ActivityLog({ logs }: ActivityLogProps) {
  const getLogIcon = (type: string) => {
    switch (type) {
      case 'emergency':
        return <CheckCircle className="text-red-500" size={16} />;
      case 'test':
        return <CheckCircle className="text-green-500" size={16} />;
      case 'location_share':
        return <MapPin className="text-blue-500" size={16} />;
      case 'sms_sent':
        return <CheckCircle className="text-blue-500" size={16} />;
      case 'call_initiated':
        return <CheckCircle className="text-green-500" size={16} />;
      default:
        return <UserCheck className="text-amber-500" size={16} />;
    }
  };

  const getLogText = (log: any) => {
    switch (log.type) {
      case 'emergency':
        return `Emergency Alert ${log.status === 'completed' ? 'Completed' : 'Triggered'}`;
      case 'test':
        return 'Test Alert Completed';
      case 'location_share':
        return 'Location Shared';
      case 'sms_sent':
        return 'Emergency SMS Sent';
      case 'call_initiated':
        return 'Emergency Call Placed';
      default:
        return log.message || 'Unknown Activity';
    }
  };

  const formatTime = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
    const diffDays = Math.floor(diffHours / 24);

    if (diffHours < 1) {
      return 'Just now';
    } else if (diffHours < 24) {
      return `${diffHours} hour${diffHours > 1 ? 's' : ''} ago`;
    } else if (diffDays < 7) {
      return `${diffDays} day${diffDays > 1 ? 's' : ''} ago`;
    } else {
      return date.toLocaleDateString();
    }
  };

  return (
    <Card className="bg-white border border-gray-200">
      <CardContent className="p-5">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-dark-text">Recent Activity</h3>
          <Button variant="ghost" size="sm" className="text-info-blue hover:text-blue-600">
            View All
          </Button>
        </div>
        
        {logs.length > 0 ? (
          <div className="space-y-3">
            {logs.slice(0, 3).map((log) => (
              <div key={log.id} className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg">
                <div className="w-8 h-8 bg-white rounded-full flex items-center justify-center border">
                  {getLogIcon(log.type)}
                </div>
                <div className="flex-1">
                  <p className="text-sm font-medium text-dark-text">{getLogText(log)}</p>
                  <p className="text-xs text-gray-600">{formatTime(log.createdAt)}</p>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-8">
            <Clock className="mx-auto text-gray-400 mb-2" size={24} />
            <p className="text-gray-600">No recent activity</p>
          </div>
        )}
        
        <div className="text-center mt-4">
          <p className="text-xs text-gray-500">All activity is encrypted and secure</p>
        </div>
      </CardContent>
    </Card>
  );
}
