import { Shield, ShieldCheck, Smartphone } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

interface StatusCardProps {
  currentTime: Date;
  isShakeDetectionActive: boolean;
  activeLog?: any;
}

export function StatusCard({ currentTime, isShakeDetectionActive, activeLog }: StatusCardProps) {
  const isEmergencyActive = activeLog?.status === 'active';
  
  return (
    <Card className={`${isEmergencyActive ? 'bg-gradient-to-r from-red-500 to-red-600' : 'bg-gradient-to-r from-green-500 to-green-600'} text-white`}>
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-3">
            {isEmergencyActive ? (
              <Shield className="text-white" size={24} />
            ) : (
              <ShieldCheck className="text-white" size={24} />
            )}
            <div>
              <h2 className="text-lg font-semibold">
                Status: {isEmergencyActive ? 'Emergency Active' : 'Safe'}
              </h2>
              <p className="text-sm opacity-90">
                {isEmergencyActive ? 'Emergency in progress' : 'All systems active'}
              </p>
            </div>
          </div>
          <div className="text-right">
            <div className="text-2xl font-bold">
              {currentTime.toLocaleTimeString([], { 
                hour: '2-digit', 
                minute: '2-digit' 
              })}
            </div>
            <div className="text-sm opacity-90">
              {currentTime.toLocaleDateString([], { weekday: 'long' })}
            </div>
          </div>
        </div>
        
        <div className="flex items-center space-x-2 bg-white bg-opacity-20 rounded-lg p-3">
          <Smartphone className="text-white" size={20} />
          <div className="flex-1">
            <p className="text-sm font-medium">Shake Detection</p>
            <p className="text-xs opacity-90">3 shakes to activate emergency</p>
          </div>
          <div className="w-12 h-6 bg-white bg-opacity-30 rounded-full flex items-center">
            <div className={`w-5 h-5 rounded-full ml-1 shadow-sm transition-transform ${
              isShakeDetectionActive ? 'bg-white translate-x-5' : 'bg-white bg-opacity-50'
            }`} />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
