import { useLocation } from "wouter";
import { Shield, Phone, Clock, Settings } from "lucide-react";
import { Button } from "@/components/ui/button";

export function BottomNavigation() {
  const [location, setLocation] = useLocation();

  const navItems = [
    { path: "/", icon: Shield, label: "Dashboard" },
    { path: "/contacts", icon: Phone, label: "Contacts" },
    { path: "/history", icon: Clock, label: "History" },
    { path: "/settings", icon: Settings, label: "Settings" },
  ];

  return (
    <nav className="sticky bottom-0 bg-white border-t border-gray-200 p-4">
      <div className="flex justify-around">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = location === item.path;
          
          return (
            <Button
              key={item.path}
              variant="ghost"
              className={`flex flex-col items-center space-y-1 ${
                isActive ? "text-info-blue" : "text-gray-400"
              }`}
              onClick={() => setLocation(item.path)}
            >
              <Icon size={20} />
              <span className="text-xs">{item.label}</span>
            </Button>
          );
        })}
      </div>
    </nav>
  );
}