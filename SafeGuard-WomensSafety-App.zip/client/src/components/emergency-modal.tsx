import { useState, useEffect } from "react";
import { AlertTriangle, CheckCircle, Loader2, Phone, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface EmergencyModalProps {
  isOpen: boolean;
  onClose: () => void;
  emergencyContact?: any;
}

export function EmergencyModal({ isOpen, onClose, emergencyContact }: EmergencyModalProps) {
  const [progress, setProgress] = useState<Array<{
    id: string;
    text: string;
    status: 'pending' | 'loading' | 'completed' | 'failed';
  }>>([]);
  const { toast } = useToast();

  useEffect(() => {
    if (isOpen && emergencyContact) {
      simulateEmergencyProgress();
    }
  }, [isOpen, emergencyContact]);

  const simulateEmergencyProgress = async () => {
    const fullPhoneNumber = emergencyContact ? `${emergencyContact.countryCode || "+1"}${emergencyContact.phoneNumber}` : '';
    
    const steps = [
      { id: 'location', text: 'GPS location acquired', status: 'loading' as const },
      { id: 'sms', text: `Sending emergency SMS to ${fullPhoneNumber}...`, status: 'pending' as const },
      { id: 'call', text: `Initiating emergency call to ${fullPhoneNumber}...`, status: 'pending' as const },
    ];

    setProgress(steps);

    // Simulate location acquisition
    setTimeout(() => {
      setProgress(prev => prev.map(step => 
        step.id === 'location' ? { ...step, status: 'completed', text: 'GPS location acquired and formatted' } : step
      ));
    }, 1000);

    // Simulate SMS sending
    setTimeout(() => {
      setProgress(prev => prev.map(step => 
        step.id === 'sms' ? { ...step, status: 'loading' } : step
      ));
    }, 1500);

    setTimeout(() => {
      setProgress(prev => prev.map(step => 
        step.id === 'sms' ? { ...step, status: 'completed', text: `Emergency SMS sent to ${fullPhoneNumber}` } : step
      ));
    }, 4000);

    // Simulate call initiation
    setTimeout(() => {
      setProgress(prev => prev.map(step => 
        step.id === 'call' ? { ...step, status: 'loading' } : step
      ));
    }, 4500);

    setTimeout(() => {
      setProgress(prev => prev.map(step => 
        step.id === 'call' ? { ...step, status: 'completed', text: `Emergency call placed to ${fullPhoneNumber}` } : step
      ));
    }, 7000);
  };

  const handleCancel = async () => {
    try {
      // Find active emergency log and cancel it
      const activeLogResponse = await fetch('/api/emergency-logs/active');
      const activeLog = await activeLogResponse.json();
      
      if (activeLog) {
        await apiRequest('PUT', `/api/emergency-logs/${activeLog.id}`, {
          status: 'cancelled'
        });
      }
      
      onClose();
      toast({
        title: "Emergency Cancelled",
        description: "Emergency alert has been cancelled.",
      });
    } catch (error) {
      toast({
        title: "Cancel Failed",
        description: "Failed to cancel emergency alert.",
        variant: "destructive",
      });
    }
  };

  const handleConfirm = async () => {
    try {
      const activeLogResponse = await fetch('/api/emergency-logs/active');
      const activeLog = await activeLogResponse.json();
      
      if (activeLog) {
        await apiRequest('PUT', `/api/emergency-logs/${activeLog.id}`, {
          status: 'completed'
        });
      }
      
      onClose();
      toast({
        title: "Emergency Confirmed",
        description: "Emergency alert has been confirmed and completed.",
      });
    } catch (error) {
      toast({
        title: "Confirm Failed",
        description: "Failed to confirm emergency alert.",
        variant: "destructive",
      });
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed':
        return <CheckCircle className="text-green-500" size={20} />;
      case 'loading':
        return <Loader2 className="text-blue-500 animate-spin" size={20} />;
      case 'failed':
        return <X className="text-red-500" size={20} />;
      default:
        return <div className="w-5 h-5 bg-gray-300 rounded-full" />;
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md bg-white">
        <DialogHeader>
          <DialogTitle className="text-center">
            <div className="w-24 h-24 bg-red-500 rounded-full flex items-center justify-center mx-auto mb-6 animate-pulse">
              <AlertTriangle className="text-white" size={32} />
            </div>
            <div className="text-2xl font-bold text-dark-text mb-2">Emergency Alert Active</div>
          </DialogTitle>
          <DialogDescription className="text-center text-gray-600">
            Contacting emergency contact and sharing location...
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-3 mb-6">
          {progress.map((step) => (
            <div 
              key={step.id}
              className={`flex items-center space-x-3 p-3 rounded-lg ${
                step.status === 'completed' ? 'bg-green-50' :
                step.status === 'loading' ? 'bg-blue-50' :
                'bg-gray-50'
              }`}
            >
              {getStatusIcon(step.status)}
              <span className="text-sm text-dark-text">{step.text}</span>
            </div>
          ))}
        </div>

        <div className="flex space-x-3">
          <Button
            onClick={handleCancel}
            variant="outline"
            className="flex-1 py-3 px-4 text-dark-text"
          >
            Cancel
          </Button>
          <Button
            onClick={handleConfirm}
            className="flex-1 py-3 px-4 bg-red-500 hover:bg-red-600 text-white"
          >
            Confirm Emergency
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
