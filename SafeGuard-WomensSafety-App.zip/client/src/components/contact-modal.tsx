import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

const contactSchema = z.object({
  name: z.string().min(1, "Name is required"),
  phoneNumber: z.string().regex(/^[1-9]\d{4,14}$/, "Invalid phone number format (no country code)"),
  countryCode: z.string().regex(/^\+[1-9]\d{0,3}$/, "Invalid country code format"),
  relationship: z.string().min(1, "Relationship is required"),
  isPrimary: z.boolean().default(true),
});

type ContactForm = z.infer<typeof contactSchema>;

interface ContactModalProps {
  isOpen: boolean;
  onClose: () => void;
  contact?: any;
}

export function ContactModal({ isOpen, onClose, contact }: ContactModalProps) {
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);

  const form = useForm<ContactForm>({
    resolver: zodResolver(contactSchema),
    defaultValues: {
      name: contact?.name || "",
      phoneNumber: contact?.phoneNumber || "",
      countryCode: contact?.countryCode || "+1",
      relationship: contact?.relationship || "Family Member",
      isPrimary: contact?.isPrimary || true,
    },
  });

  const onSubmit = async (data: ContactForm) => {
    setIsLoading(true);
    try {
      if (contact) {
        await apiRequest("PUT", `/api/emergency-contacts/${contact.id}`, data);
        toast({
          title: "Contact Updated",
          description: "Emergency contact has been updated successfully.",
        });
      } else {
        await apiRequest("POST", "/api/emergency-contacts", data);
        toast({
          title: "Contact Added",
          description: "Emergency contact has been added successfully.",
        });
      }
      
      // Invalidate queries to refresh data
      queryClient.invalidateQueries({ queryKey: ["/api/emergency-contacts"] });
      queryClient.invalidateQueries({ queryKey: ["/api/emergency-contacts/primary"] });
      
      onClose();
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to save emergency contact. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleClose = () => {
    form.reset();
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-md bg-white">
        <DialogHeader>
          <DialogTitle className="text-xl font-bold text-dark-text">
            {contact ? "Edit Emergency Contact" : "Add Emergency Contact"}
          </DialogTitle>
          <DialogDescription className="text-gray-600">
            {contact ? "Update your emergency contact information" : "Add a new emergency contact who will receive alerts"}
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
          <div>
            <Label htmlFor="name" className="text-sm font-medium text-dark-text">
              Full Name
            </Label>
            <Input
              id="name"
              {...form.register("name")}
              placeholder="Enter contact name"
              className="mt-1"
            />
            {form.formState.errors.name && (
              <p className="text-sm text-red-500 mt-1">
                {form.formState.errors.name.message}
              </p>
            )}
          </div>

          <div>
            <Label htmlFor="countryCode" className="text-sm font-medium text-dark-text">
              Country Code
            </Label>
            <Select
              value={form.watch("countryCode")}
              onValueChange={(value) => form.setValue("countryCode", value)}
            >
              <SelectTrigger className="mt-1">
                <SelectValue placeholder="Select country code" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="+1">🇺🇸 United States (+1)</SelectItem>
                <SelectItem value="+44">🇬🇧 United Kingdom (+44)</SelectItem>
                <SelectItem value="+91">🇮🇳 India (+91)</SelectItem>
                <SelectItem value="+92">🇵🇰 Pakistan (+92)</SelectItem>
                <SelectItem value="+86">🇨🇳 China (+86)</SelectItem>
                <SelectItem value="+81">🇯🇵 Japan (+81)</SelectItem>
                <SelectItem value="+49">🇩🇪 Germany (+49)</SelectItem>
                <SelectItem value="+33">🇫🇷 France (+33)</SelectItem>
                <SelectItem value="+39">🇮🇹 Italy (+39)</SelectItem>
                <SelectItem value="+34">🇪🇸 Spain (+34)</SelectItem>
                <SelectItem value="+7">🇷🇺 Russia (+7)</SelectItem>
                <SelectItem value="+55">🇧🇷 Brazil (+55)</SelectItem>
                <SelectItem value="+61">🇦🇺 Australia (+61)</SelectItem>
                <SelectItem value="+82">🇰🇷 South Korea (+82)</SelectItem>
                <SelectItem value="+52">🇲🇽 Mexico (+52)</SelectItem>
                <SelectItem value="+27">🇿🇦 South Africa (+27)</SelectItem>
                <SelectItem value="+234">🇳🇬 Nigeria (+234)</SelectItem>
                <SelectItem value="+20">🇪🇬 Egypt (+20)</SelectItem>
                <SelectItem value="+966">🇸🇦 Saudi Arabia (+966)</SelectItem>
                <SelectItem value="+971">🇦🇪 UAE (+971)</SelectItem>
                <SelectItem value="+65">🇸🇬 Singapore (+65)</SelectItem>
              </SelectContent>
            </Select>
            {form.formState.errors.countryCode && (
              <p className="text-sm text-red-500 mt-1">
                {form.formState.errors.countryCode.message}
              </p>
            )}
          </div>

          <div>
            <Label htmlFor="phoneNumber" className="text-sm font-medium text-dark-text">
              Phone Number
            </Label>
            <div className="flex mt-1">
              <div className="flex items-center px-3 bg-gray-50 border border-r-0 border-gray-200 rounded-l-md">
                <span className="text-sm font-medium text-gray-700">
                  {form.watch("countryCode") || "+1"}
                </span>
              </div>
              <Input
                id="phoneNumber"
                {...form.register("phoneNumber")}
                placeholder="555123456"
                className="rounded-l-none"
              />
            </div>
            <p className="text-xs text-gray-600 mt-1">
              Enter phone number without country code
            </p>
            {form.formState.errors.phoneNumber && (
              <p className="text-sm text-red-500 mt-1">
                {form.formState.errors.phoneNumber.message}
              </p>
            )}
          </div>

          <div>
            <Label htmlFor="relationship" className="text-sm font-medium text-dark-text">
              Relationship
            </Label>
            <Select
              value={form.watch("relationship")}
              onValueChange={(value) => form.setValue("relationship", value)}
            >
              <SelectTrigger className="mt-1">
                <SelectValue placeholder="Select relationship" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Family Member">Family Member</SelectItem>
                <SelectItem value="Friend">Friend</SelectItem>
                <SelectItem value="Colleague">Colleague</SelectItem>
                <SelectItem value="Partner">Partner</SelectItem>
                <SelectItem value="Other">Other</SelectItem>
              </SelectContent>
            </Select>
            {form.formState.errors.relationship && (
              <p className="text-sm text-red-500 mt-1">
                {form.formState.errors.relationship.message}
              </p>
            )}
          </div>

          <div className="flex space-x-3 pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={handleClose}
              className="flex-1"
              disabled={isLoading}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              className="flex-1 bg-green-500 hover:bg-green-600 text-white"
              disabled={isLoading}
            >
              {isLoading ? "Saving..." : contact ? "Update Contact" : "Save Contact"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
