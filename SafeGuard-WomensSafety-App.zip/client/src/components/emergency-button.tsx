import { useState } from "react";
import { AlertTriangle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

interface EmergencyButtonProps {
  onEmergencyTrigger: () => void;
  isActive?: boolean;
}

export function EmergencyButton({ onEmergencyTrigger, isActive = false }: EmergencyButtonProps) {
  const [isPressed, setIsPressed] = useState(false);
  const [pressTimer, setPressTimer] = useState<NodeJS.Timeout | null>(null);

  const handleMouseDown = () => {
    setIsPressed(true);
    const timer = setTimeout(() => {
      onEmergencyTrigger();
      setIsPressed(false);
    }, 3000);
    setPressTimer(timer);
  };

  const handleMouseUp = () => {
    setIsPressed(false);
    if (pressTimer) {
      clearTimeout(pressTimer);
      setPressTimer(null);
    }
  };

  const handleClick = () => {
    if (!isPressed) {
      onEmergencyTrigger();
    }
  };

  return (
    <Button
      className={cn(
        "w-48 h-48 bg-gradient-to-br from-red-500 to-red-600 hover:from-red-600 hover:to-red-700 rounded-full shadow-2xl border-8 border-white mx-auto flex items-center justify-center group transition-all duration-300",
        isActive && "emergency-pulse",
        isPressed && "scale-95"
      )}
      onMouseDown={handleMouseDown}
      onMouseUp={handleMouseUp}
      onMouseLeave={handleMouseUp}
      onTouchStart={handleMouseDown}
      onTouchEnd={handleMouseUp}
      onClick={handleClick}
      disabled={isActive}
    >
      <div className="text-center">
        <AlertTriangle className="text-white mb-2 mx-auto" size={48} />
        <div className="text-white font-bold text-xl">SOS</div>
        <div className="text-white text-sm opacity-90">EMERGENCY</div>
      </div>
    </Button>
  );
}
