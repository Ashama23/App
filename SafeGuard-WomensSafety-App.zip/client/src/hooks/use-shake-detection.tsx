import { useEffect, useRef } from "react";

interface ShakeDetectionOptions {
  threshold?: number;
  timeWindow?: number;
  requiredShakes?: number;
}

export function useShakeDetection(
  onShake: (shakeCount: number) => void,
  options: ShakeDetectionOptions = {}
) {
  const {
    threshold = 15,
    timeWindow = 1000,
    requiredShakes = 3,
  } = options;

  const lastShake = useRef<number>(0);
  const shakeCount = useRef<number>(0);
  const shakeTimeout = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    if (typeof window === 'undefined' || !window.DeviceMotionEvent) {
      return;
    }

    const handleDeviceMotion = (event: DeviceMotionEvent) => {
      const { accelerationIncludingGravity } = event;
      
      if (!accelerationIncludingGravity) return;

      const { x, y, z } = accelerationIncludingGravity;
      if (x === null || y === null || z === null) return;

      const acceleration = Math.sqrt(x * x + y * y + z * z);
      const now = Date.now();

      if (acceleration > threshold) {
        if (now - lastShake.current > 100) { // Debounce shakes
          shakeCount.current++;
          lastShake.current = now;

          // Clear existing timeout
          if (shakeTimeout.current) {
            clearTimeout(shakeTimeout.current);
          }

          // Set timeout to reset shake count
          shakeTimeout.current = setTimeout(() => {
            shakeCount.current = 0;
          }, timeWindow);

          // Trigger callback with current shake count
          onShake(shakeCount.current);

          // Reset count after reaching required shakes
          if (shakeCount.current >= requiredShakes) {
            shakeCount.current = 0;
            if (shakeTimeout.current) {
              clearTimeout(shakeTimeout.current);
            }
          }
        }
      }
    };

    // Request permission for device motion (iOS 13+)
    if (typeof (DeviceMotionEvent as any).requestPermission === 'function') {
      (DeviceMotionEvent as any).requestPermission()
        .then((permissionState: string) => {
          if (permissionState === 'granted') {
            window.addEventListener('devicemotion', handleDeviceMotion);
          }
        })
        .catch(console.error);
    } else {
      // For Android and older iOS
      window.addEventListener('devicemotion', handleDeviceMotion);
    }

    return () => {
      window.removeEventListener('devicemotion', handleDeviceMotion);
      if (shakeTimeout.current) {
        clearTimeout(shakeTimeout.current);
      }
    };
  }, [onShake, threshold, timeWindow, requiredShakes]);
}
