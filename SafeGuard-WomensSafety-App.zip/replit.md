# Emergency Response System

## Overview

This is a full-stack web application designed for emergency response and safety. It features a React frontend with a Node.js/Express backend, providing real-time emergency alerts, location tracking, and emergency contact management. The system includes shake detection for mobile devices and automated SMS/call capabilities during emergencies.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **UI Library**: Radix UI components with shadcn/ui styling system
- **Styling**: Tailwind CSS with custom emergency-themed color palette
- **State Management**: TanStack Query for server state management
- **Routing**: Wouter for lightweight client-side routing with 4 main pages
- **Build Tool**: Vite for fast development and optimized builds
- **Navigation**: Shared bottom navigation component across all pages

### Backend Architecture
- **Runtime**: Node.js with Express framework
- **Language**: TypeScript with ES modules
- **API Design**: RESTful API with JSON responses
- **Error Handling**: Centralized error middleware with structured error responses
- **Request Logging**: Custom middleware for API request/response logging

### Database Layer
- **ORM**: Drizzle ORM for type-safe database operations
- **Database**: PostgreSQL (configured via Neon serverless)
- **Schema Management**: Drizzle Kit for migrations and schema management
- **Session Storage**: PostgreSQL with connect-pg-simple for session persistence

## Key Components

### Emergency Response Features
- **Emergency Button**: Large, prominent button for triggering alerts
- **Shake Detection**: Mobile device motion detection for hands-free activation
- **Location Services**: Browser geolocation API for emergency positioning
- **SMS Automation**: Immediate SMS sending with location to emergency contact
- **Call Automation**: Automatic call initiation to emergency contact
- **Multi-Country Support**: International phone number support with country codes
- **Emergency Contacts**: Management system for emergency contact information
- **Activity Logging**: Comprehensive logging of all emergency activities

### Data Models
- **Users**: Basic user authentication and identification
- **Emergency Contacts**: Contact information with country codes and primary contact designation
- **Emergency Logs**: Activity tracking with status management (active, completed, cancelled, failed)
- **SMS Logs**: Tracking of sent emergency SMS messages
- **Call Logs**: Tracking of initiated emergency calls

### UI Components
- **Status Cards**: Real-time system status and time display
- **Modal Systems**: Emergency progress tracking and contact management
- **Activity Feeds**: Historical emergency activity with visual indicators
- **Bottom Navigation**: Consistent navigation across all pages
- **Responsive Design**: Mobile-first approach with touch-friendly interfaces

### Application Pages
- **Dashboard**: Main emergency interface with SOS button and quick actions
- **Contacts**: Emergency contact management with add/edit/delete functionality
- **History**: Complete activity log with detailed emergency event tracking
- **Settings**: App configuration and privacy controls

## Data Flow

1. **Emergency Activation**: User triggers emergency via button press or shake detection
2. **Location Acquisition**: System requests and captures current location with Google Maps link
3. **Contact Notification**: System identifies primary emergency contact
4. **SMS Automation**: Immediately sends emergency SMS with location to primary contact
5. **Call Automation**: Automatically initiates emergency call to primary contact
6. **Activity Logging**: All actions logged with timestamps and status updates
7. **Real-time Updates**: Frontend polls for status changes during active emergencies

## External Dependencies

### Frontend Dependencies
- **@radix-ui**: Comprehensive UI component library for accessible interfaces
- **@tanstack/react-query**: Server state management with caching and synchronization
- **@hookform/resolvers**: Form validation with Zod schema integration
- **wouter**: Lightweight routing solution
- **date-fns**: Date manipulation and formatting utilities
- **embla-carousel**: Carousel component for UI elements

### Backend Dependencies
- **drizzle-orm**: Type-safe ORM for database operations
- **@neondatabase/serverless**: PostgreSQL serverless database client
- **connect-pg-simple**: PostgreSQL session store for Express
- **zod**: Schema validation for API requests and responses

### Development Tools
- **Vite**: Build tool with hot module replacement
- **TypeScript**: Static type checking across the stack
- **Tailwind CSS**: Utility-first CSS framework
- **ESBuild**: Fast JavaScript bundler for production builds

## Deployment Strategy

### Development Environment
- **Dev Server**: Vite development server with Express API proxy
- **Hot Reload**: Full-stack hot module replacement for rapid development
- **Error Handling**: Runtime error overlay for debugging
- **Database**: Local PostgreSQL or Neon development database

### Production Build
- **Frontend**: Vite builds optimized static assets to `dist/public`
- **Backend**: ESBuild compiles TypeScript server code to `dist/index.js`
- **Static Serving**: Express serves built frontend assets in production
- **Environment Variables**: Database URL and other config via environment variables

### Database Management
- **Schema**: Shared schema definition in TypeScript
- **Migrations**: Drizzle Kit generates and applies database migrations
- **Connection**: PostgreSQL connection with automatic SSL in production
- **Session Storage**: PostgreSQL-backed session management for authentication

The system is designed for rapid deployment on platforms like Replit, with automatic database provisioning and environment setup. The architecture supports both development and production environments with minimal configuration changes.