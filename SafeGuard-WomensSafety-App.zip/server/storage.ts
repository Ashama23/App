import { 
  users, 
  emergencyContacts, 
  emergencyLogs,
  type User, 
  type InsertUser,
  type EmergencyContact,
  type InsertEmergencyContact,
  type EmergencyLog,
  type InsertEmergencyLog
} from "@shared/schema";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Emergency Contacts
  getEmergencyContacts(userId: number): Promise<EmergencyContact[]>;
  getPrimaryEmergencyContact(userId: number): Promise<EmergencyContact | undefined>;
  getEmergencyContact(id: number): Promise<EmergencyContact | undefined>;
  createEmergencyContact(contact: InsertEmergencyContact): Promise<EmergencyContact>;
  updateEmergencyContact(id: number, contact: Partial<EmergencyContact>): Promise<EmergencyContact | undefined>;
  deleteEmergencyContact(id: number): Promise<boolean>;
  
  // Emergency Logs
  getEmergencyLogs(userId: number): Promise<EmergencyLog[]>;
  createEmergencyLog(log: InsertEmergencyLog): Promise<EmergencyLog>;
  updateEmergencyLog(id: number, log: Partial<EmergencyLog>): Promise<EmergencyLog | undefined>;
  getActiveEmergencyLog(userId: number): Promise<EmergencyLog | undefined>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private emergencyContacts: Map<number, EmergencyContact>;
  private emergencyLogs: Map<number, EmergencyLog>;
  private currentUserId: number;
  private currentContactId: number;
  private currentLogId: number;

  constructor() {
    this.users = new Map();
    this.emergencyContacts = new Map();
    this.emergencyLogs = new Map();
    this.currentUserId = 1;
    this.currentContactId = 1;
    this.currentLogId = 1;
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getEmergencyContacts(userId: number): Promise<EmergencyContact[]> {
    return Array.from(this.emergencyContacts.values()).filter(
      (contact) => contact.userId === userId
    );
  }

  async getPrimaryEmergencyContact(userId: number): Promise<EmergencyContact | undefined> {
    return Array.from(this.emergencyContacts.values()).find(
      (contact) => contact.userId === userId && contact.isPrimary
    );
  }

  async getEmergencyContact(id: number): Promise<EmergencyContact | undefined> {
    return this.emergencyContacts.get(id);
  }

  async createEmergencyContact(insertContact: InsertEmergencyContact): Promise<EmergencyContact> {
    const id = this.currentContactId++;
    const contact: EmergencyContact = {
      ...insertContact,
      id,
      isPrimary: insertContact.isPrimary ?? false,
      countryCode: insertContact.countryCode ?? "+1",
      isVerified: false,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.emergencyContacts.set(id, contact);
    return contact;
  }

  async updateEmergencyContact(id: number, updateData: Partial<EmergencyContact>): Promise<EmergencyContact | undefined> {
    const contact = this.emergencyContacts.get(id);
    if (!contact) return undefined;

    const updatedContact = { ...contact, ...updateData, updatedAt: new Date() };
    this.emergencyContacts.set(id, updatedContact);
    return updatedContact;
  }

  async deleteEmergencyContact(id: number): Promise<boolean> {
    return this.emergencyContacts.delete(id);
  }

  async getEmergencyLogs(userId: number): Promise<EmergencyLog[]> {
    return Array.from(this.emergencyLogs.values())
      .filter((log) => log.userId === userId)
      .sort((a, b) => new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime());
  }

  async createEmergencyLog(insertLog: InsertEmergencyLog): Promise<EmergencyLog> {
    const id = this.currentLogId++;
    const log: EmergencyLog = {
      ...insertLog,
      id,
      location: insertLog.location ?? null,
      message: insertLog.message ?? null,
      contactId: insertLog.contactId ?? null,
      createdAt: new Date(),
      completedAt: null,
    };
    this.emergencyLogs.set(id, log);
    return log;
  }

  async updateEmergencyLog(id: number, updateData: Partial<EmergencyLog>): Promise<EmergencyLog | undefined> {
    const log = this.emergencyLogs.get(id);
    if (!log) return undefined;

    const updatedLog = { ...log, ...updateData };
    if (updateData.status === 'completed' || updateData.status === 'cancelled' || updateData.status === 'failed') {
      updatedLog.completedAt = new Date();
    }
    this.emergencyLogs.set(id, updatedLog);
    return updatedLog;
  }

  async getActiveEmergencyLog(userId: number): Promise<EmergencyLog | undefined> {
    return Array.from(this.emergencyLogs.values()).find(
      (log) => log.userId === userId && log.status === 'active'
    );
  }
}

export const storage = new MemStorage();
