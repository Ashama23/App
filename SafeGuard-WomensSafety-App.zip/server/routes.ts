import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertEmergencyContactSchema, insertEmergencyLogSchema } from "@shared/schema";
import { z } from "zod";
import archiver from "archiver";
import * as fs from "fs";
import * as path from "path";

export async function registerRoutes(app: Express): Promise<Server> {
  // Emergency Contacts routes
  app.get("/api/emergency-contacts", async (req, res) => {
    try {
      const userId = 1; // Mock user ID - in real app, get from session
      const contacts = await storage.getEmergencyContacts(userId);
      res.json(contacts);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch emergency contacts" });
    }
  });

  app.get("/api/emergency-contacts/primary", async (req, res) => {
    try {
      const userId = 1; // Mock user ID
      const contact = await storage.getPrimaryEmergencyContact(userId);
      res.json(contact || null);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch primary emergency contact" });
    }
  });

  app.post("/api/emergency-contacts", async (req, res) => {
    try {
      const userId = 1; // Mock user ID
      const contactData = insertEmergencyContactSchema.parse({
        ...req.body,
        userId,
      });
      
      // If this is set as primary, unset other primary contacts
      if (contactData.isPrimary) {
        const existingContacts = await storage.getEmergencyContacts(userId);
        for (const contact of existingContacts) {
          if (contact.isPrimary) {
            await storage.updateEmergencyContact(contact.id, { isPrimary: false });
          }
        }
      }

      const contact = await storage.createEmergencyContact(contactData);
      res.json(contact);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid contact data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to create emergency contact" });
      }
    }
  });

  app.put("/api/emergency-contacts/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updateData = req.body;
      
      if (updateData.isPrimary) {
        const userId = 1; // Mock user ID
        const existingContacts = await storage.getEmergencyContacts(userId);
        for (const contact of existingContacts) {
          if (contact.isPrimary && contact.id !== id) {
            await storage.updateEmergencyContact(contact.id, { isPrimary: false });
          }
        }
      }

      const contact = await storage.updateEmergencyContact(id, updateData);
      if (!contact) {
        return res.status(404).json({ message: "Emergency contact not found" });
      }
      res.json(contact);
    } catch (error) {
      res.status(500).json({ message: "Failed to update emergency contact" });
    }
  });

  app.delete("/api/emergency-contacts/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const deleted = await storage.deleteEmergencyContact(id);
      if (!deleted) {
        return res.status(404).json({ message: "Emergency contact not found" });
      }
      res.json({ message: "Emergency contact deleted" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete emergency contact" });
    }
  });

  // Emergency Logs routes
  app.get("/api/emergency-logs", async (req, res) => {
    try {
      const userId = 1; // Mock user ID
      const logs = await storage.getEmergencyLogs(userId);
      res.json(logs);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch emergency logs" });
    }
  });

  app.post("/api/emergency-logs", async (req, res) => {
    try {
      const userId = 1; // Mock user ID
      const logData = insertEmergencyLogSchema.parse({
        ...req.body,
        userId,
      });
      
      const log = await storage.createEmergencyLog(logData);
      res.json(log);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid log data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to create emergency log" });
      }
    }
  });

  app.put("/api/emergency-logs/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updateData = req.body;
      
      const log = await storage.updateEmergencyLog(id, updateData);
      if (!log) {
        return res.status(404).json({ message: "Emergency log not found" });
      }
      res.json(log);
    } catch (error) {
      res.status(500).json({ message: "Failed to update emergency log" });
    }
  });

  app.get("/api/emergency-logs/active", async (req, res) => {
    try {
      const userId = 1; // Mock user ID
      const log = await storage.getActiveEmergencyLog(userId);
      res.json(log || null);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch active emergency log" });
    }
  });

  // Emergency trigger endpoint
  app.post("/api/emergency/trigger", async (req, res) => {
    try {
      const userId = 1; // Mock user ID
      const { location, type = 'emergency' } = req.body;
      
      // Check if there's already an active emergency
      const activeLog = await storage.getActiveEmergencyLog(userId);
      if (activeLog) {
        return res.status(400).json({ message: "Emergency already active" });
      }

      // Get primary emergency contact
      const primaryContact = await storage.getPrimaryEmergencyContact(userId);
      if (!primaryContact) {
        return res.status(400).json({ message: "No primary emergency contact set" });
      }

      // Create Google Maps link
      const googleMapsLink = location ? 
        `https://maps.google.com/?q=${location.latitude},${location.longitude}` : 
        'Location unavailable';

      // Create emergency log
      const log = await storage.createEmergencyLog({
        userId,
        type,
        status: 'active',
        location: JSON.stringify(location),
        contactId: primaryContact.id,
        message: `Emergency alert triggered at ${new Date().toISOString()}`,
      });

      // Simulate SMS sending (in real implementation, integrate with SMS service)
      const smsMessage = `🚨 EMERGENCY ALERT from SafeGuard App\n\nYour emergency contact needs immediate help!\n\nLocation: ${googleMapsLink}\n\nTime: ${new Date().toLocaleString()}\n\nThis is an automated emergency alert. Please respond immediately.`;
      
      // Create SMS log entry
      await storage.createEmergencyLog({
        userId,
        type: 'sms_sent',
        status: 'completed',
        location: JSON.stringify(location),
        contactId: primaryContact.id,
        message: `SMS sent to ${primaryContact.countryCode}${primaryContact.phoneNumber}: ${smsMessage}`,
      });

      // Simulate call initiation (in real implementation, integrate with calling service)
      setTimeout(async () => {
        await storage.createEmergencyLog({
          userId,
          type: 'call_initiated',
          status: 'completed',
          location: JSON.stringify(location),
          contactId: primaryContact.id,
          message: `Emergency call initiated to ${primaryContact.countryCode}${primaryContact.phoneNumber}`,
        });
      }, 2000);

      res.json({ 
        log, 
        contact: primaryContact,
        smsMessage,
        fullPhoneNumber: `${primaryContact.countryCode}${primaryContact.phoneNumber}`,
        googleMapsLink
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to trigger emergency alert" });
    }
  });

  // Location sharing endpoint
  app.post("/api/location/share", async (req, res) => {
    try {
      const userId = 1; // Mock user ID
      const { location } = req.body;
      
      const log = await storage.createEmergencyLog({
        userId,
        type: 'location_share',
        status: 'completed',
        location: JSON.stringify(location),
        message: `Location shared at ${new Date().toISOString()}`,
      });

      res.json(log);
    } catch (error) {
      res.status(500).json({ message: "Failed to share location" });
    }
  });

  // Project download endpoint
  app.get("/api/download-project", async (req, res) => {
    try {
      const projectRoot = path.resolve(process.cwd());
      const archive = archiver('zip', {
        zlib: { level: 9 }
      });

      // Set response headers
      res.setHeader('Content-Type', 'application/zip');
      res.setHeader('Content-Disposition', 'attachment; filename="SafeGuard-WomensSafety-App.zip"');

      // Pipe archive data to response
      archive.pipe(res);

      // Add all project files except node_modules, .git, and build artifacts
      const excludePatterns = [
        'node_modules/**',
        '.git/**',
        'dist/**',
        '.replit',
        'replit.nix',
        '*.log',
        '.env*',
        'coverage/**',
        '.nyc_output/**',
        'temp/**',
        'tmp/**'
      ];

      // Add files with exclusions
      archive.glob('**/*', {
        cwd: projectRoot,
        ignore: excludePatterns,
        dot: false
      });

      // Add essential files that might be hidden
      const essentialFiles = [
        'package.json',
        'package-lock.json',
        'tsconfig.json',
        'vite.config.ts',
        'tailwind.config.ts',
        'postcss.config.js',
        'drizzle.config.ts',
        '.gitignore'
      ];

      for (const file of essentialFiles) {
        const filePath = path.join(projectRoot, file);
        if (fs.existsSync(filePath)) {
          archive.file(filePath, { name: file });
        }
      }

      // Add README.md with setup instructions
      const readmeContent = `# SafeGuard Women's Safety App

## Overview
A comprehensive emergency response web application with shake detection, GPS location sharing, and automated emergency alerts.

## Features
- Emergency SOS system with shake detection
- GPS location sharing with Google Maps integration
- Automated SMS and call alerts
- International phone number support (20+ countries)
- Emergency contact management
- Activity logging and history
- Mobile-first responsive design
- Real-time emergency status updates

## Quick Setup

### Prerequisites
- Node.js 18+ 
- npm package manager
- Modern web browser

### Installation Steps
1. Extract the ZIP file to your desired location
2. Open terminal/command prompt in the project folder
3. Install dependencies:
   \`\`\`bash
   npm install
   \`\`\`

4. Start the development server:
   \`\`\`bash
   npm run dev
   \`\`\`

5. Open your browser and navigate to: http://localhost:5000

## Project Structure
- \`client/\` - React frontend with TypeScript
- \`server/\` - Express.js backend
- \`shared/\` - Shared schemas and types
- \`package.json\` - Project dependencies and scripts

## Key Technologies
- Frontend: React 18, TypeScript, Tailwind CSS, Vite
- Backend: Node.js, Express, TypeScript
- Database: PostgreSQL (with in-memory storage for development)
- UI: Radix UI components with shadcn/ui

## Available Scripts
- \`npm run dev\` - Start development server
- \`npm run build\` - Build for production
- \`npm start\` - Start production server
- \`npm run db:generate\` - Generate database migrations
- \`npm run db:push\` - Push schema changes

## Default Features
- Dashboard with emergency button
- Emergency contacts management
- Activity history tracking
- Settings and configuration
- Pakistan (+92) country code support

## Support
For issues or questions, refer to the code comments and documentation within the project files.

Happy coding! 🚨`;

      archive.append(readmeContent, { name: 'README.md' });

      // Finalize the archive
      await archive.finalize();

    } catch (error) {
      console.error('Error creating project archive:', error);
      res.status(500).json({ message: "Failed to create project download" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
