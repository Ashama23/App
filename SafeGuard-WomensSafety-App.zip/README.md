# SafeGuard - Women's Safety App

A comprehensive women's safety web application that provides emergency assistance through shake detection, GPS location sharing, and automated contact alerts.

## Features

### Core Emergency Features
- **Shake Detection**: Activate emergency alerts by shaking phone 3 times
- **GPS Location Sharing**: Automatic location capture and sharing via Google Maps links
- **Automated SMS Alerts**: Instant SMS notifications to emergency contacts
- **Automated Emergency Calls**: Direct call initiation to primary emergency contact
- **Emergency Contact Management**: Add, edit, and manage emergency contacts
- **Activity Logging**: Comprehensive tracking of all emergency activities

### Additional Features
- **International Phone Support**: Support for 20+ countries including Pakistan (+92)
- **Mobile-First Design**: Responsive interface optimized for mobile devices
- **Real-Time Updates**: Live status updates during emergency situations
- **Multi-Page Navigation**: Dashboard, Contacts, History, and Settings pages
- **User-Friendly Interface**: Emergency-themed color scheme with intuitive navigation

## Tech Stack

### Frontend
- **React 18** with TypeScript
- **Tailwind CSS** for styling
- **Radix UI** components with shadcn/ui
- **TanStack Query** for state management
- **Wouter** for routing
- **Vite** for build tooling

### Backend
- **Node.js** with Express
- **TypeScript** for type safety
- **Drizzle ORM** for database operations
- **PostgreSQL** database (with in-memory storage for development)
- **Zod** for schema validation

## Installation & Setup

### Prerequisites
- Node.js (version 18 or higher)
- npm package manager

### Quick Start

1. **Clone the repository**
   ```bash
   git clone [repository-url]
   cd safeguard-app
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Run the application**
   ```bash
   npm run dev
   ```

4. **Access the application**
   - Open your browser to `http://localhost:5000`
   - The app will automatically open with the dashboard

## Available Scripts

### Development
```bash
npm run dev
```
Starts the development server with both frontend and backend. The app will be available at `http://localhost:5000`.

### Build
```bash
npm run build
```
Builds the application for production. Creates optimized bundles in the `dist/` directory.

### Start Production
```bash
npm start
```
Starts the production server (requires running `npm run build` first).

### Database Management
```bash
npm run db:generate
```
Generates database migration files using Drizzle Kit.

```bash
npm run db:push
```
Pushes database schema changes to the database.

## Project Structure

```
safeguard-app/
├── client/                 # Frontend React application
│   ├── src/
│   │   ├── components/     # Reusable UI components
│   │   ├── pages/          # Main application pages
│   │   ├── hooks/          # Custom React hooks
│   │   └── lib/            # Utility functions
│   └── index.html
├── server/                 # Backend Express application
│   ├── index.ts           # Server entry point
│   ├── routes.ts          # API route definitions
│   └── storage.ts         # Data storage layer
├── shared/                 # Shared types and schemas
│   └── schema.ts          # Database schema definitions
└── README.md
```

## Key Components

### Emergency System
- **EmergencyButton**: Large SOS button for triggering alerts
- **EmergencyModal**: Real-time emergency progress display
- **ShakeDetection**: Device motion detection for hands-free activation

### Contact Management
- **ContactModal**: Add/edit emergency contacts with international support
- **ContactList**: View and manage all emergency contacts
- **CountryCodeSelector**: Support for 20+ countries

### Navigation & UI
- **BottomNavigation**: Consistent navigation across all pages
- **StatusCard**: Real-time system status display
- **ActivityLog**: Historical emergency activity tracking

## Configuration

### Environment Variables
Create a `.env` file in the project root:

```env
DATABASE_URL=postgresql://username:password@localhost:5432/safeguard
NODE_ENV=development
```

### Database Setup
The application uses PostgreSQL for production and in-memory storage for development. No additional database setup is required for development.

## Emergency Workflow

1. **Emergency Trigger**: User presses SOS button or shakes device 3 times
2. **Location Capture**: App requests and captures GPS coordinates
3. **Contact Notification**: System identifies primary emergency contact
4. **SMS Alert**: Automatic SMS sent with location and Google Maps link
5. **Emergency Call**: Automatic call initiated to primary contact
6. **Activity Logging**: All actions logged with timestamps and status

## Browser Support

- Chrome (recommended)
- Firefox
- Safari
- Edge

## Mobile Support

The application is optimized for mobile devices with:
- Touch-friendly interface
- Responsive design
- Device motion detection
- Geolocation services

## Security Features

- Input validation using Zod schemas
- Secure session management
- Location data encryption
- Emergency contact verification

## Contributing

1. Fork the repository
2. Create a feature branch: `git checkout -b feature-name`
3. Commit changes: `git commit -m 'Add feature'`
4. Push to branch: `git push origin feature-name`
5. Submit a pull request

## License

This project is licensed under the MIT License.

## Support

For technical support or questions:
- Check the FAQ in the Settings page
- Contact support through the app's Settings > Support section
- File issues in the repository

## Version History

- **v1.0.0**: Initial release with core emergency features
- **v1.1.0**: Added international phone support and Pakistan country code
- **v1.2.0**: Added full page navigation and enhanced UI

---

**Emergency Services Disclaimer**: This application is designed to complement, not replace, official emergency services. Always call your local emergency number (911, 999, etc.) for immediate emergency assistance.