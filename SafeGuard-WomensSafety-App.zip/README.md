# SafeGuard Women's Safety App

## Overview
A comprehensive emergency response web application with shake detection, GPS location sharing, and automated emergency alerts.

## Features
- Emergency SOS system with shake detection
- GPS location sharing with Google Maps integration
- Automated SMS and call alerts
- International phone number support (20+ countries)
- Emergency contact management
- Activity logging and history
- Mobile-first responsive design
- Real-time emergency status updates

## Quick Setup

### Prerequisites
- Node.js 18+ 
- npm package manager
- Modern web browser

### Installation Steps
1. Extract the ZIP file to your desired location
2. Open terminal/command prompt in the project folder
3. Install dependencies:
   ```bash
   npm install
   ```

4. Start the development server:
   ```bash
   npm run dev
   ```

5. Open your browser and navigate to: http://localhost:5000

## Project Structure
- `client/` - React frontend with TypeScript
- `server/` - Express.js backend
- `shared/` - Shared schemas and types
- `package.json` - Project dependencies and scripts

## Key Technologies
- Frontend: React 18, TypeScript, Tailwind CSS, Vite
- Backend: Node.js, Express, TypeScript
- Database: PostgreSQL (with in-memory storage for development)
- UI: Radix UI components with shadcn/ui

## Available Scripts
- `npm run dev` - Start development server
- `npm run build` - Build for production
- `npm start` - Start production server
- `npm run db:generate` - Generate database migrations
- `npm run db:push` - Push schema changes

## Default Features
- Dashboard with emergency button
- Emergency contacts management
- Activity history tracking
- Settings and configuration
- Pakistan (+92) country code support

## Support
For issues or questions, refer to the code comments and documentation within the project files.

Happy coding! 🚨