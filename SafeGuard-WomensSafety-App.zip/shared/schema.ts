import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const emergencyContacts = pgTable("emergency_contacts", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  name: text("name").notNull(),
  phoneNumber: text("phone_number").notNull(),
  countryCode: text("country_code").notNull().default("+1"),
  relationship: text("relationship").notNull(),
  isPrimary: boolean("is_primary").default(false),
  isVerified: boolean("is_verified").default(false),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const emergencyLogs = pgTable("emergency_logs", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  type: text("type").notNull(), // 'emergency', 'test', 'location_share'
  status: text("status").notNull(), // 'active', 'completed', 'cancelled', 'failed'
  location: text("location"), // JSON string with lat/lng
  contactId: integer("contact_id"),
  message: text("message"),
  createdAt: timestamp("created_at").defaultNow(),
  completedAt: timestamp("completed_at"),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertEmergencyContactSchema = createInsertSchema(emergencyContacts).pick({
  userId: true,
  name: true,
  phoneNumber: true,
  countryCode: true,
  relationship: true,
  isPrimary: true,
}).extend({
  phoneNumber: z.string().regex(/^[1-9]\d{4,14}$/, "Invalid phone number format (no country code)"),
  countryCode: z.string().regex(/^\+[1-9]\d{0,3}$/, "Invalid country code format"),
});

export const insertEmergencyLogSchema = createInsertSchema(emergencyLogs).pick({
  userId: true,
  type: true,
  status: true,
  location: true,
  contactId: true,
  message: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type EmergencyContact = typeof emergencyContacts.$inferSelect;
export type InsertEmergencyContact = z.infer<typeof insertEmergencyContactSchema>;
export type EmergencyLog = typeof emergencyLogs.$inferSelect;
export type InsertEmergencyLog = z.infer<typeof insertEmergencyLogSchema>;
